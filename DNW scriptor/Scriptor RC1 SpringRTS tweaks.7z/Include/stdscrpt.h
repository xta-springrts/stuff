/* stdscrpt.h -- Standard Scripts for ground vehicles */

#ifndef __STDSCRPT_H_
#define __STDSCRPT_H_


/*
** Activate() -- Called when the unit is done building and ready for action
*/

Activate()
	{
	}

#endif
